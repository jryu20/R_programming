
## Question 1

gcd <- function(x, y) {
  # This function returns the greatest common divisor of two integers
  # Throws an error if the inputs are NOT integers or length 1
  # Args:
  # x: an integer, size 1 
  # y: an integer, size 1
  # Return:
  # A numeric, size 1, which is the greatest common divisor of x and y
  
  if (class(x) != "numeric" | class(y) != "numeric") {
    stop("Your inputs must be a number")
  }
  
  if (length(x) != 1 | length(y) != 1) {
    stop("Your inputs must be of length 1")
  }
  
  if (!(x%%1 == 0 && y%%1 == 0)) {
    stop("Your inputs must be integers")
  }

  x <- abs(x)
  y <- abs(y)
  
  if (x < y) {
    temp <- x
    x <- y
    y <- temp
  }
  
  remainder <- character(1)
  while (remainder != 0) {
    remainder <- x %% y
    x <- y
    y <- remainder
  }
  
  x
}


lcm <- function(v) {
  # This function returns the least common multiple of elements in an array (all integers) 
  # This will throw an error if the input elements are NOT integers
  # Args:
  # v : a numeric vector where all elements are integers
  # Return:
  # A numeric, size 1, which is the least common multiple of all elements in v
  
  # error-testing is inherited from the gcd function

  lcm_update <- v[1]*v[2]/(gcd(v[1], v[2]))
  
  if (length(v) > 2) {
    for (i in 3:length(v)) {
      lcm_update <- lcm_update*v[i]/(gcd(lcm_update, v[i]))
    }
  }
  
  lcm_update
}



## Question 2

is_prime <- function(v) {
  # This function returns whether each element in an array is a prime number
  # This will throw an error if the input elements are NOT positive integers
  # Args:
  # v : a numeric vector where all elements positive integers
  # Return:
  # A logical array which tells whether each element is prime or not
  
  
  prime <- !logical(length(v))
  for (i in 1:length(v)) {
    if (class(v[i]) != "numeric" & class(v[i]) != "integer") {
      stop("Your inputs must be a positive integer")
    }
    if (v[i] %% 1 != 0 | v[i] < 1) {
      stop("Your inputs must be a positive integer")
    }
    
    
    if (v[i] == 2) {
      next
    } else {
      end <- v[i]/2
      for (j in 2:end) {
        if (v[i] %% j == 0) {
          prime[i] <- FALSE
          next
        }
      }
    }
    
  }
  prime
}


get_factors <- function(x) {
  # This function returns a list consisting of a number's prime factors and their respective exponents
  # This will throw an error if the input is NOT a positive integer
  # Args:
  # x : a positive integer, size 1
  # Return:
  # A list whose first element is a numeric vector of the prime factors and the second element is a numeric vector of the factors' respective exponents
  
  
  if (class(x) != "numeric" | length(x) > 1) {
    stop("Your inputs must be a positive integer")
  }
  if((x%%1 != 0) | x < 1) {
    stop("Your input must be a positive integer")
  }
  
  L <- list("primes" = numeric(0))
  for (i in 2:x) {
    if (x%%i == 0) {
      if (is_prime(i)) {
        L$primes = c(L$primes, i)
      }
    }
  }
  
  L$exponents = numeric(length(L$primes))
  for (j in 1:length(L$primes)) {
    while (x%%L$primes[j] == 0) {
      L$exponents[j] = L$exponents[j]+1
      x = x/L$primes[j]
      
    }
  }
  
  L
}